package com.maybank.carisma.questionnaire.constant;

public interface QuestionnaireConstant {

	/**
	 * Questions in section is empty
	 */
	public static final String ERR_CODE_01 = "ERR_CODE_01";

	/**
	 * QUESTIONNAIRE_COMPLETED
	 */
	public static final String ERR_CODE_02 = "ERR_CODE_02";

	/**
	 * Questionnaire Id null
	 * 
	 */
	public static final String ERR_CODE_03 = "ERR_CODE_03";

	/**
	 * Section Empty
	 */
	public static final String ERR_CODE_04 = "ERR_CODE_04";

	/**
	 * QUESTIONNAIRE_COMPLETED
	 */
	public static final String MSG_CODE_01 = "MSG_CODE_01";

	/**
	 * QUESTIONNAIRE_INCOMPLETED
	 */
	public static final String MSG_CODE_02 = "MSG_CODE_02";

	/**
	 * QUESTIONNAIRE_SAVED
	 */
	public static final String QUESTIONNAIRE_SAVED = "QUESTIONNAIRE_SAVED";

	/**
	 * QUESTIONNAIRE_SAVED_AS_DRAFT => Mandatory field(s) skipped & saved as draft
	 */
	public static final String QUESTIONNAIRE_SAVED_AS_DRAFT = "QUESTIONNAIRE_SAVED_AS_DRAFT";

	/**
	 * QUESTIONNAIRE_WITH_ANSWER
	 */
	public static final String QUESTIONNAIRE_WITH_ANSWER = "QUESTIONNAIRE_WITH_ANSWER";

	/**
	 * QUESTIONNAIRE_WITHOUT_ANSWER
	 */
	public static final String QUESTIONNAIRE_WITHOUT_ANSWER = "QUESTIONNAIRE_WITHOUT_ANSWER";

	// Component Name for Messages
	public static final String QUESTIONNAIRE_COMPONENT = "Questionnaire";

	public static final String STATIC = "static";
	
	public static final String DYNAMIC = "dynamic";

	public static final Object DISPLAY_TYPE_HS = "HS"; // Hide or Show

	public static final Object DISPLAY_TYPE_ED = "ED"; // Enable or Disable
	
	public static final String MODULE_CRRS1 = "CRRS1"; 
	
}
