package com.maybank.carisma.questionnaire.vo;

/**
 * The Class QuestionDescVo.
 * 
 *  @author Sangit Banik
 */
public class QuestionDescVo {
 
	/** The msgcode. */
	private String msgcode;
	
	/** The msg desc. */
	private String msgDesc;
	
	/** The msg lang. */
	private String msgLang;

	/**
	 * Gets the msgcode.
	 *
	 * @return the msgcode
	 */
	public String getMsgcode() {
		return msgcode;
	}

	/**
	 * Sets the msgcode.
	 *
	 * @param msgcode the new msgcode
	 */
	public void setMsgcode(String msgcode) {
		this.msgcode = msgcode;
	}

	/**
	 * Gets the msg desc.
	 *
	 * @return the msg desc
	 */
	public String getMsgDesc() {
		return msgDesc;
	}

	/**
	 * Sets the msg desc.
	 *
	 * @param msgDesc the new msg desc
	 */
	public void setMsgDesc(String msgDesc) {
		this.msgDesc = msgDesc;
	}

	/**
	 * Gets the msg lang.
	 *
	 * @return the msg lang
	 */
	public String getMsgLang() {
		return msgLang;
	}

	/**
	 * Sets the msg lang.
	 *
	 * @param msgLang the new msg lang
	 */
	public void setMsgLang(String msgLang) {
		this.msgLang = msgLang;
	}
}
