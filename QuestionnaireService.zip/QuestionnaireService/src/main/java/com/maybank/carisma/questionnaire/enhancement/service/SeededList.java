package com.maybank.carisma.questionnaire.enhancement.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class SeededList {
	@PersistenceContext
	protected EntityManager entityManager;
	
	public List<String> getSeededList(String tableName,String colName) {
		String query = "select "+colName+" FROM "+tableName+" ORDER BY "+colName;
		Query q = entityManager.createNativeQuery(query);
		List<String> seededList = q.getResultList();
		return seededList;
	}
}
