package com.maybank.carisma.questionnaire.vo;

import java.util.Comparator;

/**
 * The Class SortBySortOrder.
 * 
 *  @author Sangit Banik
 */
public class SortBySortOrder implements Comparator<SubSectionDetails>{

	
	@Override
	public int compare(SubSectionDetails a, SubSectionDetails b) {
		Long value=a.getSectionOrder()-b.getSectionOrder();
		
		return value.intValue();
	}

}
