package com.maybank.carisma.questionnaire.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class QuestionMasterValidationBean {

	private long questionValidationId;

	@JsonIgnore
	private long questionnaireId;

	@JsonIgnore
	private long questionMasterId;

	@Deprecated
	private String name;

	/* validationType is replacement for name */
	private String validationType;

	@Deprecated
	private String value;

	private String validationValue;

	/* remarkMandatoryValidation is replacement for remarkValidation */
	private String remarkMandatoryValidation;
	
	@Deprecated
	private String remarkValidation;

	@JsonIgnore
	private String errorCode;

	private String errorMsg;

	private String regex;

	public long getQuestionValidationId() {
		return questionValidationId;
	}

	public QuestionMasterValidationBean setQuestionValidationId(long questionValidationId) {
		this.questionValidationId = questionValidationId;
		return this;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public QuestionMasterValidationBean setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public long getQuestionMasterId() {
		return questionMasterId;
	}

	public QuestionMasterValidationBean setQuestionMasterId(long questionMasterId) {
		this.questionMasterId = questionMasterId;
		return this;
	}

	@Deprecated
	public String getName() {
		return name;
	}

	@Deprecated
	public QuestionMasterValidationBean setName(String name) {
		this.name = name;
		this.validationType = name;
		return this;
	}

	public String getValidationType() {
		return validationType;
	}

	public QuestionMasterValidationBean setValidationType(String validationType) {
		this.name = validationType;
		this.validationType = validationType;
		return this;
	}

	@Deprecated
	public String getValue() {
		//return value;
		return getValidationValue();
	}

	@Deprecated
	public QuestionMasterValidationBean setValue(String value) {
		this.value = value;
		this.validationValue = value;
		return this;
	}

	public String getValidationValue() {
		return validationValue;
	}

	public QuestionMasterValidationBean setValidationValue(String validationValue) {
		this.value = validationValue;
		this.validationValue = validationValue;
		return this;
	}

	public String getRemarkMandatoryValidation() {
		return remarkMandatoryValidation;
	}

	public QuestionMasterValidationBean setRemarkMandatoryValidation(String remarkMandatoryValidation) {
		this.remarkValidation = remarkMandatoryValidation;
		this.remarkMandatoryValidation = remarkMandatoryValidation;
		return this;
	}

	@Deprecated
	public String getRemarkValidation() {
		return remarkValidation;
	}

	@Deprecated
	public QuestionMasterValidationBean setRemarkValidation(String remarkValidation) {
		this.remarkValidation = remarkValidation;
		this.remarkMandatoryValidation = remarkValidation;
		return this;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public QuestionMasterValidationBean setErrorCode(String errorCode) {
		this.errorCode = errorCode;
		return this;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public QuestionMasterValidationBean setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
		return this;
	}

	public String getRegex() {
		return regex;
	}

	public QuestionMasterValidationBean setRegex(String regex) {
		this.regex = regex;
		return this;
	}

	@Override
	public String toString() {
		return "QuestionMasterValidationBean [questionValidationId=" + questionValidationId + ", questionnaireId="
				+ questionnaireId + ", questionMasterId=" + questionMasterId + ", name=" + name + ", validationType="
				+ validationType + ", value=" + value + ", validationValue=" + validationValue
				+ ", remarkMandatoryValidation=" + remarkMandatoryValidation + ", remarkValidation=" + remarkValidation
				+ ", errorCode=" + errorCode + ", errorMsg=" + errorMsg + ", regex=" + regex + "]";
	}

}
