package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;

public class SelectOption implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1540301362849966241L;

	private String value;

	private String label;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

}
