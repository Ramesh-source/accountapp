package com.maybank.carisma.questionnaire.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.maybank.carisma.constant.ExecutionStatus;
import com.maybank.carisma.questionnaire.service.QuestionnaireSaveService;
import com.maybank.carisma.questionnaire.service.QuestionnaireService;
import com.maybank.carisma.questionnaire.vo.QuestionDTO;
import com.maybank.carisma.questionnaire.vo.QuestionRequest;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.QuestionSaveResponse;
import com.maybank.carisma.questionnaire.vo.QuestionnaireDTO;
import com.maybank.carisma.questionnaire.vo.QuestionnaireProperties;
import com.maybank.carisma.questionnaire.vo.QuestionnaireSaveRequest;

@Controller
@RequestMapping("/")
public class QuestionnaireController {

	private static final Logger logger = LogManager.getLogger(QuestionnaireController.class);

	private Map<String, QuestionnaireProperties> quesProps;

	@Autowired
	QuestionnaireService questionnaireService;

	@Autowired
	QuestionnaireSaveService saveService;

	@PostConstruct
	@Transactional
	public void init() {
		quesProps = saveService.getQuestionnaireProperties();
	}

	@RequestMapping(value = { "/questionnaire" }, method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionnaireDTO questionnaire(@RequestParam("type") String type) {
		QuestionnaireDTO questionnaireDTO = new QuestionnaireDTO();
		List<QuestionDTO> questionDTO = new ArrayList<>();
		try {
			questionDTO = questionnaireService.retrieveQuestions(type);
			questionnaireDTO.setQuestionnaireList(questionDTO);
		} catch (Exception e) {
			logger.error("Error occured while fetching questions: " + e.getMessage());
		}

		return questionnaireDTO;
	}

	@RequestMapping(value = { "/questionObject" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionResponse singleQuestion(@RequestBody QuestionRequest request) {
		QuestionResponse response = new QuestionResponse();
		try {
			long startTime = System.currentTimeMillis();
			response = questionnaireService.retriveSingleQuestion(request);
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
			response.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
		} catch (Exception e) {
			logger.error("Error occured while fetching questions: " + e.getMessage());
			response.addErrorDetail("Error occured while fetching questions");
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
		}
		return response;

	}

	@RequestMapping(value = {
			"/saveQuestionnaire" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionSaveResponse saveQuestion(@RequestBody QuestionnaireSaveRequest request) {
		QuestionSaveResponse response = new QuestionSaveResponse();
		try {
			long startTime = System.currentTimeMillis();
			saveService.saveQuestionAnswer(request, quesProps);
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
			response.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.addErrorDetail("Error occured while saving questions and answers");
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return response;
		}

	}

	@RequestMapping(value = {
			"/questionJson" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionResponse getQuestionJson(@RequestBody QuestionRequest request) {
		QuestionResponse response = new QuestionResponse();
		try {
			long startTime = System.currentTimeMillis();
			response = questionnaireService.retriveQuestionJson(request.getEntityType(),request.getPrimaryIdentifier(), quesProps);
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
			response.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
		} catch (Exception e) {
			logger.error("Error occured while fetching questions: " + e.getMessage());
			response.addErrorDetail("Error occured while fetching questions");
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
		}
		return response;

	}
}
