package com.maybank.carisma.questionnaire.vo;

/**
 * The Class SectionProperties.
 * 
 *  @author Sangit Banik
 */
public class SectionProperties {

	/** The section id. */
	private long sectionId;

	/** The multiple response flag. */
	private boolean multipleResponseFlag;
	
	/** The response style. */
	private String responseStyle;
	
	/** The response table. */
	private String responseTable;

	/**
	 * Checks if is multiple response flag.
	 *
	 * @return true, if is multiple response flag
	 */
	public boolean isMultipleResponseFlag() {
		return multipleResponseFlag;
	}

	/**
	 * Sets the multiple response flag.
	 *
	 * @param multipleResponseFlag the new multiple response flag
	 */
	public void setMultipleResponseFlag(boolean multipleResponseFlag) {
		this.multipleResponseFlag = multipleResponseFlag;
	}

	/**
	 * Gets the response style.
	 *
	 * @return the response style
	 */
	public String getResponseStyle() {
		return responseStyle;
	}

	/**
	 * Sets the response style.
	 *
	 * @param responseStyle the new response style
	 */
	public void setResponseStyle(String responseStyle) {
		this.responseStyle = responseStyle;
	}

	/**
	 * Gets the response table.
	 *
	 * @return the response table
	 */
	public String getResponseTable() {
		return responseTable;
	}

	/**
	 * Sets the response table.
	 *
	 * @param responseTable the new response table
	 */
	public void setResponseTable(String responseTable) {
		this.responseTable = responseTable;
	}

	/**
	 * Gets the section id.
	 *
	 * @return the section id
	 */
	public long getSectionId() {
		return sectionId;
	}

	/**
	 * Sets the section id.
	 *
	 * @param sectionId the new section id
	 */
	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}
}
