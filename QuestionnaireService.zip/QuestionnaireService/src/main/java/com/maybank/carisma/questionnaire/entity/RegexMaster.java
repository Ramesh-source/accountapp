/**
 * 
 */
package com.maybank.carisma.questionnaire.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author 00132020
 *
 */
@Entity
@Table(name="setup_regex_master")
@NamedQuery(name="REGEX_VALUE", query="SELECT regexValue FROM RegexMaster WHERE regexType = :type")
public class RegexMaster {

	@Id
	@Column(name="n_regex_skey")
	private Integer regexId;
	
	@Column(name="v_regex_type_name")
	private String regexType;
	
	@Column(name="v_regex_value")
	private String regexValue;
	
}
