package com.maybank.carisma.questionnaire.enhancement.enumeration;

public enum SectionDirection {

	FORWARD, BACKWARD;

}
