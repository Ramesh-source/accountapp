package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;
import java.util.List;

/**
 * The Class SectionDetails.
 * 
 * @author Sangit Banik
 */
public class SectionDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The section name. */
	private String sectionName;

	/** The section id. */
	private long sectionId;

	/** The sub section details. */
	private List<SubSectionDetails> subSectionDetails;

	/** The multiple responses. */
	private boolean multipleResponses;

	/** The section order. */
	private Long sectionOrder;
	
	/** The section Help Link. */
	private String sectionHref;	

	/**
	 * Gets the section name.
	 *
	 * @return the section name
	 */
	public String getSectionName() {
		return sectionName;
	}

	/**
	 * Sets the section name.
	 *
	 * @param sectionName the new section name
	 */
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	/**
	 * Gets the section id.
	 *
	 * @return the section id
	 */
	public long getSectionId() {
		return sectionId;
	}

	/**
	 * Sets the section id.
	 *
	 * @param sectionId the new section id
	 */
	public void setSectionId(Long sectionId) {
		this.sectionId = sectionId;
	}

	/**
	 * Gets the section order.
	 *
	 * @return the section order
	 */
	public Long getSectionOrder() {
		return sectionOrder;
	}

	/**
	 * Sets the section order.
	 *
	 * @param sectionOrder the new section order
	 */
	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	/**
	 * Gets the sub section details.
	 *
	 * @return the sub section details
	 */
	public List<SubSectionDetails> getSubSectionDetails() {
		return subSectionDetails;
	}

	/**
	 * Sets the sub section details.
	 *
	 * @param subSectionDetails the new sub section details
	 */
	public void setSubSectionDetails(List<SubSectionDetails> subSectionDetails) {
		this.subSectionDetails = subSectionDetails;
	}

	/**
	 * Checks if is multiple responses.
	 *
	 * @return true, if is multiple responses
	 */
	public boolean isMultipleResponses() {
		return multipleResponses;
	}

	/**
	 * Sets the multiple responses.
	 *
	 * @param multipleResponses the new multiple responses
	 */
	public void setMultipleResponses(boolean multipleResponses) {
		this.multipleResponses = multipleResponses;
	}
	
	/**
	 * Gets the section Link.
	 *
	 * @return the section Link
	 */
	public String getSectionHref() {
		return sectionHref;
	}

	/**
	 * Sets the section Link.
	 *
	 * @param sectionHref the new section Link
	 */
	public void setSectionHref(String sectionHref) {
		this.sectionHref = sectionHref;
	}	

}
