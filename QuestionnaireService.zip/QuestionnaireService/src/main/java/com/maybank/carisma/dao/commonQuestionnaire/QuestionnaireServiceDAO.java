package com.maybank.carisma.dao.commonQuestionnaire;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.maybank.carisma.dao.CarismaBaseDAO;
import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;
import com.maybank.carisma.questionnaire.entity.ComponentMetadata;
import com.maybank.carisma.questionnaire.entity.QuestionMasterValidation;
import com.maybank.carisma.questionnaire.entity.QuestionRemarkMap;
import com.maybank.carisma.questionnaire.entity.Questionnaire;

@Repository
public class QuestionnaireServiceDAO extends CarismaBaseDAO {

	private static final Logger LOGGER = LogManager.getLogger(QuestionnaireServiceDAO.class);

	private static final String COMMA = ",";

	public List<Object[]> getQuestionaireData(String questionaireType) {
		String query = "select qm.nQuestionMasterId,qm.vQuestion,avl.vOption,avl.fIsLeaf,n.questionMaster,avl.nAvlOptionsToQuestionsId,m.nOrder,qm.vOptionSelectionType,qm.questionType,qm.formName,q.isStatic,qm.isDisplayNone, qm.optionsStatic, qm.query, qs.nQuestionnaireSectionsId, qs.sectionCode, qs.sectionOrder, q.typeOfDisplay, qs.fMulpitpleSections from Questionnaire q INNER JOIN q.questionnaireSections qs INNER JOIN qs.questionnaireQuestionMaps m INNER JOIN m.questionMaster qm LEFT OUTER JOIN qm.avlOptionsToQuestions avl LEFT OUTER JOIN avl.questionOptionsNavigations n where q.vQuestionnaireName=:type order by qs.sectionOrder, m.nOrder, avl.nAvlOptionsToQuestionsId";

		/**
		 * String query = "select
		 * qm.nQuestionMasterId,qm.vQuestion,avl.vOption,avl.fIsLeaf,n.questionMaster,avl.nAvlOptionsToQuestionsId,m.nOrder,qm.vOptionSelectionType,qm.questionType,qm.formName
		 * from Questionnaire q INNER JOIN q.questionnaireQuestionMaps m INNER JOIN
		 * m.questionMaster qm LEFT OUTER JOIN qm.avlOptionsToQuestions avl LEFT OUTER
		 * JOIN avl.questionOptionsNavigations n where q.vQuestionnaireName=:type order
		 * by m.nOrder,avl.nAvlOptionsToQuestionsId"; String query = "SELECT
		 * qm.n_question_master_id, qm.v_question, avl.v_option, avl.f_is_leaf,
		 * n.n_question_master_id as questionMaster, avl.n_avl_options_to_questions_id,
		 * m.n_order, qm.v_option_selection_type, qm.question_type, qm.form_name,
		 * q.f_is_static, qm.f_is_default_visible, qm.f_options_static, qm.v_query FROM
		 * questionnaire q INNER JOIN questionnaire_question_map m ON
		 * q.n_questionnaire_id = m.n_questionnaire_id INNER JOIN question_master qm ON
		 * m.n_question_master_id = qm.n_question_master_id LEFT OUTER JOIN
		 * avl_options_to_questions avl ON qm.n_question_master_id =
		 * avl.n_question_master_id LEFT OUTER JOIN question_options_navigation n ON
		 * avl.n_avl_options_to_questions_id = n.n_avl_options_to_questions_id WHERE
		 * q.v_questionnaire_name = :type ORDER BY m.n_order,
		 * avl.n_avl_options_to_questions_id";
		 */
		Query q = em.createQuery(query);
		q.setParameter("type", questionaireType);
		List<Object[]> results = q.getResultList();
		return results;
	}

	public List<Object[]> getDescriptions() {

		String query = "SELECT A.V_MSG_CODE, B.V_DISPLAY_MESSAGE, B.V_LANGUAGE_CD FROM MESSAGE_MASTER A LEFT OUTER JOIN MESSAGE_LOCALE_DETAILS B ON A.N_MESSAGE_ID = B.N_MESSAGE_ID WHERE A.V_COMPONENT = :theComponent";
		Query q = em.createNativeQuery(query);
		q.setParameter("theComponent", QuestionnaireConstant.QUESTIONNAIRE_COMPONENT);
		List<Object[]> results = q.getResultList();
		return results;

	}

	public List<Object[]> getDynamicOptions(String query) {
		Query q = em.createNativeQuery(query);
		List<Object[]> dynamicOptionsList = q.getResultList();
		return dynamicOptionsList;
	}

	public List<Object[]> extensibleAttributes() {
		List<Object[]> list = new ArrayList<>();
		String query = "SELECT LOGICAL_COLUMN_NAME,COLUMN_NAME FROM COM_COLUMNS_METADATA WHERE PHYSICAL_TABLE_NAME = 'QUESTION_MASTER_EXTN' AND COLUMN_NAME != 'N_QUESTION_MASTER_ID'  AND LOGICAL_COLUMN_NAME IS NOT NULL AND DEPRECATED_FLG ='N'";
		Query q = em.createNativeQuery(query);
		list = q.getResultList();
		return list;
	}

	public List<String> extensibleValue(long questionId, Set<String> list) {

		String dynamicQuery = String.join(COMMA, list);

		String query = "select " + dynamicQuery + " from QUESTION_MASTER_EXTN where N_QUESTION_MASTER_ID =:questionId";

		Query q = em.createNativeQuery(query);
		q.setParameter("questionId", questionId);
		List<Object[]> value = q.getResultList();
		List<String> valueList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(value)) {
			value.forEach(row -> {
				for (int j = 0; j < row.length; j++) {
					valueList.add((String) row[j]);
				}
			});
		}
		return valueList;
	}

	public List<Object[]> getAnswers(String primaryIdentifier, String entityName) {
		String query = "SELECT V_RESPONSE_TABLE_NAME FROM QUESTIONNAIRE WHERE V_QUESTIONNAIRE_NAME=:name";
		Query q = em.createNativeQuery(query);
		q.setParameter("name", entityName);
		Object tableName = q.getSingleResult();
		if (!StringUtils.isEmpty(tableName)) {
			String query1 = "SELECT N_QUESTION_MASTER_ID, N_AVL_OPTIONS_TO_QUESTIONS_ID, V_ANSWER FROM "
					+ (String) tableName + " WHERE V_PRIMARY_IDENTIFIER=:primaryIdentifier";
			Query q1 = em.createNativeQuery(query1);
			q1.setParameter("primaryIdentifier", primaryIdentifier);
			List<Object[]> results = q1.getResultList();
			return results;
		} else {
			return null;
		}
	}

	public List<QuestionMasterValidation> getAllQuestionMasterValidations() {

		return em.createNamedQuery(QuestionMasterValidation.GET_ALL_QUESTION_MASTER_VALIDATIONS, QuestionMasterValidation.class)
				.getResultList();
	}
	
	public List<ComponentMetadata> getComponentMetadata() {

		return em.createNamedQuery(ComponentMetadata.GET_ALL_COMPONENT_METADATA, ComponentMetadata.class)
				.getResultList();
	}
	
	public List<QuestionRemarkMap> getQuestionRemarkMap() {
		return em.createNamedQuery(QuestionRemarkMap.GET_ALL_QUESTION_REMARK_MAP, QuestionRemarkMap.class)
				.getResultList();
	}

	public List<String> getAllEntityTypes() {
		return em.createNamedQuery(Questionnaire.GET_ALL_ENTITY_TYPES, String.class).setParameter("isStatic", "Y")
				.getResultList();
	}

	public List<Object[]> getTableNamesForAllQuesId(String entityType) {
		String query = "select qs.nQuestionnaireSectionsId,qm.nQuestionMasterId,qm.responseColumn from Questionnaire q INNER JOIN q.questionnaireSections qs INNER JOIN qs.questionnaireQuestionMaps m INNER JOIN m.questionMaster qm where q.vQuestionnaireName=:entityType and qm.responseColumn IS NOT NULL order by qs.sectionOrder, m.nOrder";
		Query q = em.createQuery(query);
		q.setParameter("entityType", entityType);
		return q.getResultList();
	}
	
	public List<Object[]> getSectionQueryresult(String query, String ucifId){
		String sql = query + " WHERE V_UCIF_ID = :ucifId";
		Query q = em.createNativeQuery(sql);
		q.setParameter("ucifId", ucifId);
		return q.getResultList();
	}
}
