package com.maybank.carisma.questionnaire.vo;

import java.util.List;
import java.util.Map;

public class QueriesVo {

	private Map<Long, String> secQueryMap;
	private Map<Long,List<Long>> secQuestionMap;
	public Map<Long, String> getSecQueryMap() {
		return secQueryMap;
	}
	public void setSecQueryMap(Map<Long, String> secQueryMap) {
		this.secQueryMap = secQueryMap;
	}
	public Map<Long, List<Long>> getSecQuestionMap() {
		return secQuestionMap;
	}
	public void setSecQuestionMap(Map<Long, List<Long>> secQuestionMap) {
		this.secQuestionMap = secQuestionMap;
	}
	

		
}
