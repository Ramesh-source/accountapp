package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the QUESTIONNAIRE_QUESTION_MAP database table.
 * 
 */
@Entity
@Table(name = "QUESTIONNAIRE_QUESTION_MAP")
@NamedQuery(name="QuestionnaireQuestionMap.findAll", query="SELECT q FROM QuestionnaireQuestionMap q")
public class QuestionnaireQuestionMap implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4763285022235024739L;

	@Id
	@SequenceGenerator(name = "questionaireMap", sequenceName = "SEQ_QUESTIONNAIRE_MAP_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionaireMap")
	@Column(name = "N_QUESTION_MAP_ID")
	private long nQuestionMapId;

	@Column(name = "N_ORDER")
	private BigDecimal nOrder;

	// bi-directional many-to-one association to Questionnaire
	@ManyToOne
	@JoinColumn(name = "N_QUESTIONNAIRE_ID")
	private Questionnaire questionnaire;

	// bi-directional many-to-one association to QuestionMaster
	@ManyToOne
	@JoinColumn(name = "N_QUESTION_MASTER_ID")
	private QuestionMaster questionMaster;

	@ManyToOne
	@JoinColumn(name = "N_QUESTIONNAIRE_SECTIONS_ID")
	private QuestionnaireSections questionnaireSections;

	public QuestionnaireSections getQuestionnaireSections() {
		return questionnaireSections;
	}

	public void setQuestionnaireSections(QuestionnaireSections questionnaireSections) {
		this.questionnaireSections = questionnaireSections;
	}

	public long getNQuestionMapId() {
		return this.nQuestionMapId;
	}

	public void setNQuestionMapId(long nQuestionMapId) {
		this.nQuestionMapId = nQuestionMapId;
	}

	public BigDecimal getNOrder() {
		return this.nOrder;
	}

	public void setNOrder(BigDecimal nOrder) {
		this.nOrder = nOrder;
	}

	public Questionnaire getQuestionnaire() {
		return this.questionnaire;
	}

	public void setQuestionnaire(Questionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

	public QuestionMaster getQuestionMaster() {
		return this.questionMaster;
	}

	public void setQuestionMaster(QuestionMaster questionMaster) {
		this.questionMaster = questionMaster;
	}

}