package com.maybank.carisma.questionnaire.vo;

import java.util.ArrayList;
import java.util.List;

import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;
import com.maybank.carisma.questionnaire.enhancement.enumeration.SectionDirection;

public class QuestionSectionSaveVo {

	private long questionnaireId;

	private String questionnaireName;
	
	private String moduleName;

	private long requestId;

	private List<QuestionAnswerVo> ansVo = new ArrayList<QuestionAnswerVo>();

	private long nextSection;

	private SectionDirection sectionDirection;

	private List<QuestionAnswerDTO> questionAnswerDTOs = new ArrayList<QuestionAnswerDTO>();

	private Long responseRowId;

	private boolean deleteFlag = false;
	
	private Boolean isMandatoryCheckFailed = false;

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public void setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	public String getQuestionnaireName() {
		return questionnaireName;
	}

	public void setQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
	}

	public String getModuleName() {
		if(moduleName == null)
			return QuestionnaireConstant.MODULE_CRRS1;
		
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public List<QuestionAnswerVo> getAnsVo() {
		return ansVo;
	}

	public void setAnsVo(List<QuestionAnswerVo> ansVo) {
		this.ansVo = ansVo;
	}

	public long getNextSection() {
		return nextSection;
	}

	public void setNextSection(long nextSection) {
		this.nextSection = nextSection;
	}

	public SectionDirection getSectionDirection() {
		return sectionDirection;
	}

	public void setSectionDirection(SectionDirection sectionDirection) {
		this.sectionDirection = sectionDirection;
	}

	public List<QuestionAnswerDTO> getQuestionAnswerDTOs() {
		return questionAnswerDTOs;
	}

	public void setQuestionAnswerDTOs(List<QuestionAnswerDTO> questionAnswerDTOs) {
		this.questionAnswerDTOs = questionAnswerDTOs;
	}

	public Long getResponseRowId() {
		return responseRowId;
	}

	public void setResponseRowId(Long responseRowId) {
		this.responseRowId = responseRowId;
	}

	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Boolean getIsMandatoryCheckFailed() {
		return isMandatoryCheckFailed;
	}

	public void setIsMandatoryCheckFailed(Boolean isMandatoryCheckFailed) {
		this.isMandatoryCheckFailed = isMandatoryCheckFailed;
	}

	@Override
	public String toString() {
		return "QuestionSectionSaveVo [questionnaireId=" + questionnaireId + ", questionnaireName=" + questionnaireName
				+ ", moduleName=" + moduleName + ", requestId=" + requestId + ", ansVo=" + ansVo + ", nextSection="
				+ nextSection + ", sectionDirection=" + sectionDirection + ", questionAnswerDTOs=" + questionAnswerDTOs
				+ ", responseRowId=" + responseRowId + ", deleteFlag=" + deleteFlag + ", isMandatoryCheckPassed=" + isMandatoryCheckFailed
				+ "]";
	}

}
