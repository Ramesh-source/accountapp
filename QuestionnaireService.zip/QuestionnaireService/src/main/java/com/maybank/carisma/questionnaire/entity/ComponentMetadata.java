/**
 * 
 */
package com.maybank.carisma.questionnaire.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author 00132020
 *
 */
@Entity
@Table(name="question_component_metadata")
@NamedQuery(name = ComponentMetadata.GET_ALL_COMPONENT_METADATA, query = "SELECT q FROM ComponentMetadata q")
public class ComponentMetadata {

	public static final String GET_ALL_COMPONENT_METADATA="GET_ALL_COMPONENT_METADATA";
	
	@Id
	@Column(name="n_component_metadata_id")
	private Long componentMetadataId;
	
	@Column(name="n_question_master_id")
	private Long questionMasterId;
	
	@Column(name="v_component_prop_type")
	private String componentPropType;
	
	@Column(name="v_component_prop_val")
	private String componentPropVal;

	/**
	 * @return the componentMetadataId
	 */
	public Long getComponentMetadataId() {
		return componentMetadataId;
	}

	/**
	 * @param componentMetadataId the componentMetadataId to set
	 */
	public void setComponentMetadataId(Long componentMetadataId) {
		this.componentMetadataId = componentMetadataId;
	}

	/**
	 * @return the questionMasterId
	 */
	public Long getQuestionMasterId() {
		return questionMasterId;
	}

	/**
	 * @param questionMasterId the questionMasterId to set
	 */
	public void setQuestionMasterId(Long questionMasterId) {
		this.questionMasterId = questionMasterId;
	}

	/**
	 * @return the componentPropType
	 */
	public String getComponentPropType() {
		return componentPropType;
	}

	/**
	 * @param componentPropType the componentPropType to set
	 */
	public void setComponentPropType(String componentPropType) {
		this.componentPropType = componentPropType;
	}

	/**
	 * @return the componentPropVal
	 */
	public String getComponentPropVal() {
		return componentPropVal;
	}

	/**
	 * @param componentPropVal the componentPropVal to set
	 */
	public void setComponentPropVal(String componentPropVal) {
		this.componentPropVal = componentPropVal;
	}
}
