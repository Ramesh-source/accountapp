package com.maybank.carisma.questionnaire.vo;

import java.io.Serializable;

/**
 * The Class OptionDTO.
 * 
 * @author Sangit Banik
 */
public class OptionDTO implements Serializable, Comparable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1596940053336710035L;

	/** The option id. */
	private Long optionId;

	/** The option. */
	private String option;

	/** The option desc. */
	private String optionDesc;

	/** The next question. */
	private String nextQuestion;

	/** The is leaf. */
	private Boolean isLeaf;

	/** The is selected. */
	private Boolean isSelected;
	
	private Integer optionOrder;
	
	/*
	 * private String remarkDesc;
	 * 
	 * public String getRemarkDesc() { return remarkDesc; }
	 * 
	 * public void setRemarkDesc(String remarkDesc) { this.remarkDesc = remarkDesc;
	 * }
	 */

	/**
	 * @return the optionOrder
	 */
	public Integer getOptionOrder() {
		return optionOrder;
	}

	/**
	 * @param optionOrder the optionOrder to set
	 */
	public void setOptionOrder(Integer optionOrder) {
		this.optionOrder = optionOrder;
	}

	/**
	 * Gets the checks if is selected.
	 *
	 * @return the checks if is selected
	 */
	public Boolean getIsSelected() {
		return isSelected;
	}

	/**
	 * Sets the checks if is selected.
	 *
	 * @param isSelected the new checks if is selected
	 */
	public void setIsSelected(Boolean isSelected) {
		this.isSelected = isSelected;
	}

	/**
	 * Gets the option desc.
	 *
	 * @return the option desc
	 */
	public String getOptionDesc() {
		return optionDesc;
	}

	/**
	 * Sets the option desc.
	 *
	 * @param optionDesc the new option desc
	 */
	public void setOptionDesc(String optionDesc) {
		this.optionDesc = optionDesc;
	}

	/**
	 * Gets the option id.
	 *
	 * @return the option id
	 */
	public Long getOptionId() {
		return optionId;
	}

	/**
	 * Sets the option id.
	 *
	 * @param optionId the new option id
	 */
	public void setOptionId(Long optionId) {
		this.optionId = optionId;
	}

	/**
	 * Gets the option.
	 *
	 * @return the option
	 */
	public String getOption() {
		return option;
	}

	/**
	 * Sets the option.
	 *
	 * @param option the new option
	 */
	public void setOption(String option) {
		this.option = option;
	}

	/**
	 * Gets the next question.
	 *
	 * @return the next question
	 */
	public String getNextQuestion() {
		return nextQuestion;
	}

	/**
	 * Sets the next question.
	 *
	 * @param nextQuestion the new next question
	 */
	public void setNextQuestion(String nextQuestion) {
		this.nextQuestion = nextQuestion;
	}

	/**
	 * Gets the checks if is leaf.
	 *
	 * @return the checks if is leaf
	 */
	public Boolean getIsLeaf() {
		return isLeaf;
	}

	/**
	 * Sets the checks if is leaf.
	 *
	 * @param isLeaf the new checks if is leaf
	 */
	public void setIsLeaf(Boolean isLeaf) {
		this.isLeaf = isLeaf;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((optionId == null) ? 0 : optionId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OptionDTO other = (OptionDTO) obj;
		if (optionId == null) {
			if (other.optionId != null)
				return false;
		} else if (!optionId.equals(other.optionId))
			return false;
		return true;
	}

	@Override
	public int compareTo(Object o) {

		return this.optionId.compareTo(((OptionDTO) o).optionId);
	}

	@Override
	public String toString() {
		return "OptionDTO [optionId=" + optionId + ", option=" + option + ", optionDesc=" + optionDesc
				+ ", nextQuestion=" + nextQuestion + ", isLeaf=" + isLeaf + ", isSelected=" + isSelected + "]";
	}
	
	

}
