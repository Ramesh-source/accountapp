package com.maybank.carisma.questionnaire.vo;

import java.util.List;

/**
 * The Class QuestionRequest.
 * 
 *  @author Sangit Banik
 */
public class QuestionRequest {

	/** The entity type. */
	private String entityType;
	
	/** The next question. */
	private List<Long> nextQuestion;
	
	/** The primary identifier. */
	private String primaryIdentifier;

	/**
	 * Gets the entity type.
	 *
	 * @return the entity type
	 */
	public String getEntityType() {
		return entityType;
	}

	/**
	 * Sets the entity type.
	 *
	 * @param entityType the new entity type
	 */
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	/**
	 * Gets the next question.
	 *
	 * @return the next question
	 */
	public List<Long> getNextQuestion() {
		return nextQuestion;
	}

	/**
	 * Sets the next question.
	 *
	 * @param nextQuestion the new next question
	 */
	public void setNextQuestion(List<Long> nextQuestion) {
		this.nextQuestion = nextQuestion;
	}

	/**
	 * Gets the primary identifier.
	 *
	 * @return the primary identifier
	 */
	public String getPrimaryIdentifier() {
		return primaryIdentifier;
	}

	/**
	 * Sets the primary identifier.
	 *
	 * @param primaryIdentifier the new primary identifier
	 */
	public void setPrimaryIdentifier(String primaryIdentifier) {
		this.primaryIdentifier = primaryIdentifier;
	}

	
	
	
}
