package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.maybank.carisma.questionnaire.bean.QuestionAnswerKeyBean;

@Embeddable
public class QuestionAnswerKey implements Serializable {

	private static final long serialVersionUID = -2258960078483588189L;

	@Column(name = "N_REQUEST_ID")
	private long requestId;

	@Column(name = "V_QUESTIONNAIRE_ID")
	private long questionnaireId;

	@Column(name = "V_QUESTION")
	private String questionId;

	@Column(name = "V_MODULE_NAME")
	private String moduleName;

	public long getRequestId() {
		return requestId;
	}

	public QuestionAnswerKey setRequestId(long requestId) {
		this.requestId = requestId;
		return this;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public QuestionAnswerKey setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public String getQuestionId() {
		return questionId;
	}

	public QuestionAnswerKey setQuestionId(String questionId) {
		this.questionId = questionId;
		return this;
	}

	public String getModuleName() {
		return moduleName;
	}

	public QuestionAnswerKey setModuleName(String moduleName) {
		this.moduleName = moduleName;
		return this;
	}
	
	public QuestionAnswerKeyBean toBean() {
		return new QuestionAnswerKeyBean()
				.setRequestId(requestId)
				.setQuestionnaireId(questionnaireId)
				.setQuestionId(questionId)
				.setModuleName(moduleName);
	}

}
