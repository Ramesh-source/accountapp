package com.maybank.carisma.questionnaire.bean;

import java.io.Serializable;

public class QuestionAnswerKeyBean implements Serializable {

	private static final long serialVersionUID = 7130476946783582735L;
	
	private long requestId;

	private long questionnaireId;

	private String questionId;

	private String moduleName;

	public long getRequestId() {
		return requestId;
	}

	public QuestionAnswerKeyBean setRequestId(long requestId) {
		this.requestId = requestId;
		return this;
	}

	public long getQuestionnaireId() {
		return questionnaireId;
	}

	public QuestionAnswerKeyBean setQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public String getQuestionId() {
		return questionId;
	}

	public QuestionAnswerKeyBean setQuestionId(String questionId) {
		this.questionId = questionId;
		return this;
	}

	public String getModuleName() {
		return moduleName;
	}

	public QuestionAnswerKeyBean setModuleName(String moduleName) {
		this.moduleName = moduleName;
		return this;
	}

	@Override
	public String toString() {
		return "QuestionAnswerKeyBean [requestId=" + requestId + ", questionnaireId=" + questionnaireId
				+ ", questionId=" + questionId + ", moduleName=" + moduleName + "]";
	}

}
