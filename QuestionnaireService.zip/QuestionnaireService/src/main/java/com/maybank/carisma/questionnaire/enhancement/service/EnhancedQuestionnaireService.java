package com.maybank.carisma.questionnaire.enhancement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.maybank.carisma.constant.ExecutionStatus;
import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;
import com.maybank.carisma.questionnaire.enhancement.assembler.QuestionAnswerAssembler;
import com.maybank.carisma.questionnaire.enhancement.enumeration.dao.EnhancedQuestionnaireServiceDAO;
import com.maybank.carisma.questionnaire.enhancement.exception.QuestionnaireException;
import com.maybank.carisma.questionnaire.entity.QuestionAnswer;
import com.maybank.carisma.questionnaire.entity.QuestionAnswerKey;
import com.maybank.carisma.questionnaire.entity.Questionnaire;
import com.maybank.carisma.questionnaire.entity.QuestionnaireSections;
import com.maybank.carisma.questionnaire.service.QuestionnaireService;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerDTO;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerResponseDTO;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.QuestionSectionSaveVo;
import com.maybank.carisma.questionnaire.vo.SelectOption;

@Service("enhancedQuestionnaireService")
@Transactional
public class EnhancedQuestionnaireService {

	@Autowired
	QuestionnaireService questionnaireService;

	@Autowired
	EnhancedQuestionnaireServiceDAO enhancedQuestionnaireServiceDAO;

	@Autowired
	EnhancedQuestionnaireServiceHelper enhancedQuestionnaireServiceHelper;

	@Autowired
	QuestionAnswerAssembler questionAnswerAssembler;

	static boolean isDev = false;

	public QuestionAnswerResponseDTO saveOrUpdateQuestionAnswer(QuestionSectionSaveVo questionSectionsData) {
		if(questionSectionsData == null || questionSectionsData.getQuestionAnswerDTOs() == null)
			return null;

		if(questionSectionsData.getQuestionAnswerDTOs().size() == 0)
			return new QuestionAnswerResponseDTO();

		QuestionAnswerResponseDTO questionAnswerResponseDTO = new QuestionAnswerResponseDTO();

		int deleteCount = enhancedQuestionnaireServiceDAO.deleteQuestionAnswerByRequestId(questionSectionsData.getRequestId());
		System.out.println("delete from QuestionAnswer a where a.questionAnswerKey.requestId = " + questionSectionsData.getRequestId() + " [" + deleteCount +"]");

		for (QuestionAnswerDTO questionAnswerDto: questionSectionsData.getQuestionAnswerDTOs()) {
			QuestionAnswer questionAnswerEntity = new QuestionAnswer();
			questionAnswerEntity.setQuestionAnswerKey(
					new QuestionAnswerKey()
						.setRequestId(questionSectionsData.getRequestId())
						.setQuestionnaireId(questionSectionsData.getQuestionnaireId())
						.setModuleName(questionSectionsData.getModuleName())
						.setQuestionId(questionAnswerDto.getQuestionId()) // Question-Id from global.
					);


			questionAnswerEntity
				.setOptionTypes(questionAnswerDto.getOptionTypes())
				.setAnswerId(questionAnswerDto.getAnswerId())
				.setAnswerDesc(questionAnswerDto.getAnswerDesc())
				.setSectionOrder(questionAnswerDto.getSectionOrder())
				.setRemark(questionAnswerDto.getCommentDesc());			

			questionAnswerDto.setRequestId(questionSectionsData.getRequestId());
			questionAnswerDto.setQuestionnaireId(questionSectionsData.getQuestionnaireId());
			
			enhancedQuestionnaireServiceDAO.saveQuestionAnswer(questionAnswerEntity);
			System.out.println("Saved the Q/A: " + questionAnswerEntity.toBean().toString());
		}

		questionAnswerResponseDTO.setQuestionAnswerDTOList(questionSectionsData.getQuestionAnswerDTOs());
		populateAnswerDesc(questionAnswerResponseDTO.getQuestionAnswerDTOList());
		questionAnswerResponseDTO.setQuestionnaireName(questionSectionsData.getQuestionnaireName());

		return questionAnswerResponseDTO;
	}

	public List<SelectOption> getAllQuestionnaire() {
		List<SelectOption> selectOptionList = new ArrayList<SelectOption>();
		List<Questionnaire> questionnaireList = enhancedQuestionnaireServiceDAO.getAllQuestionnaire();
		for (Questionnaire questionnaire : questionnaireList) {
			SelectOption selectOption = new SelectOption();
			selectOption.setValue(String.valueOf(questionnaire.getNQuestionnaireId()));
			selectOption.setLabel(questionnaire.getVQuestionnaireName());
			selectOptionList.add(selectOption);
		}
		return selectOptionList;
	}

	public List<QuestionAnswerDTO> getQuestionAnswerByRequestId(Long requestId) {

		List<QuestionAnswerDTO> questionAnswerDTOList = new ArrayList<QuestionAnswerDTO>();
		QuestionAnswerDTO questionAnswerDTO = null;
		List<QuestionAnswer> questionAnswerList = enhancedQuestionnaireServiceDAO.getQuestionAnswerByRequestId(requestId);
		if (questionAnswerList != null && questionAnswerList.size() > 0) {
			questionAnswerDTOList = new ArrayList<QuestionAnswerDTO>();
			for (QuestionAnswer questionAnswer : questionAnswerList) {
				questionAnswerDTO = new QuestionAnswerDTO();
				questionAnswerAssembler.fromEntity(questionAnswer, questionAnswerDTO);
				questionAnswerDTOList.add(questionAnswerDTO);
			}
			populateAnswerDesc(questionAnswerDTOList);
		}
		return questionAnswerDTOList;
	}

	public void getQuestionnaire(QuestionSectionSaveVo request, QuestionResponse response)
			throws QuestionnaireException {

		long questionnaireId = 0;
		if (request.getRequestId() == 0) {
			response.setRequestId(generateRequestId());
			response.setServiceStatus(QuestionnaireConstant.QUESTIONNAIRE_WITHOUT_ANSWER);
		} else {
			populateAnswer(request, response);

			if (response.getQuestionAnswerDTOs() != null && response.getQuestionAnswerDTOs().size() > 0) {
				questionnaireId = getQuestionnaireIdForRequestId(request.getRequestId());
				request.setQuestionnaireId(questionnaireId);
				response.setRequestId(request.getRequestId());
				response.setServiceStatus(QuestionnaireConstant.QUESTIONNAIRE_WITH_ANSWER);
			} else {
				response.setRequestId(request.getRequestId());
				response.setServiceStatus(QuestionnaireConstant.QUESTIONNAIRE_WITHOUT_ANSWER);
			}
		}

		populateQuestionnaireMetaData(request, response);
	}

	public long generateRequestId() {
		long requestId = enhancedQuestionnaireServiceDAO.getRequestId();
		return requestId;
	}

	public void populateAnswer(QuestionSectionSaveVo request, QuestionResponse response) throws QuestionnaireException {

		List<QuestionAnswerDTO> questionAnswerDTOs = getQuestionAnswerByRequestId(request.getRequestId());
		populateAnswerDesc(questionAnswerDTOs);
		response.setQuestionAnswerDTOs(questionAnswerDTOs);

	}

	private void populateAnswerDesc(List<QuestionAnswerDTO> questionAnswerDTOs) {
		Locale locale = new Locale("en_US");
		if (questionAnswerDTOs != null && questionAnswerDTOs.size() > 0) {
			for (QuestionAnswerDTO questionAnswerDTO : questionAnswerDTOs) {

				try {
					if (questionAnswerDTO.getQuestionId() != null
							&& QuestionnaireService.infoMap.get(questionAnswerDTO.getQuestionId()) != null)
						questionAnswerDTO.setQuestionText(
								(String) QuestionnaireService.infoMap.get(questionAnswerDTO.getQuestionId()).get(locale));
					
					if (questionAnswerDTO.getAnswerId() != null && !questionAnswerDTO.getAnswerId().isEmpty()
							&& QuestionnaireService.infoMap.get(questionAnswerDTO.getAnswerId()) != null)
						questionAnswerDTO.setAnswerText(
								(String) QuestionnaireService.infoMap.get(questionAnswerDTO.getAnswerId()).get(locale));
				} catch (Exception e) {
					System.err.println("## " + locale + " => " + questionAnswerDTO.getQuestionId());
					System.err.println(e.getMessage());
				}
			}

		}

	}

	public long getQuestionnaireIdForRequestId(long requestId) {
		return enhancedQuestionnaireServiceDAO.getQuestionnaireIdForRequestId(requestId);
	}

	public void populateQuestionnaireMetaData(QuestionSectionSaveVo request, QuestionResponse response)
			throws QuestionnaireException {

		System.out.println("## populateQuestionnaireMetaData: getQuestionnaireId: " + request.getQuestionnaireId());
		if (isDev) {
			QuestionnaireService.infoMap = null;
			QuestionnaireService.infoMap = questionnaireService.getMessageMap();
			QuestionnaireService.mapValidationsByQuestionnaireId = questionnaireService.getValdationList();
		}

		Questionnaire questionnaire = enhancedQuestionnaireServiceDAO.getQuestionnaire(request.getQuestionnaireId());
		if(questionnaire == null) {
			response.setExecutionStatus("QUESTIONNAIRE_EMPTY");
			throw new QuestionnaireException(QuestionnaireConstant.ERR_CODE_04);
		}

		response.setQuestionnaireId(request.getQuestionnaireId());
		response.setQuestionnaireName(questionnaire.getVQuestionnaireName());
		response.setModuleName(questionnaire.getModuleName());

		List<QuestionnaireSections> questionnaireSections = enhancedQuestionnaireServiceDAO.getQuestionnaireSections(request.getQuestionnaireId());
		Locale locale = new Locale("en_US");

		if (questionnaireSections != null && questionnaireSections.size() > 0) {
			enhancedQuestionnaireServiceHelper.constructQuestionnaireResponse(questionnaire, response, locale);
			enhancedQuestionnaireServiceHelper.constructQuestionnaireSections(questionnaireSections, response, locale);
			response.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
		} else {
			response.setExecutionStatus("QUESTIONNAIRE_SECTION_EMPTY");
			throw new QuestionnaireException(QuestionnaireConstant.ERR_CODE_04);
		}
	}

}
