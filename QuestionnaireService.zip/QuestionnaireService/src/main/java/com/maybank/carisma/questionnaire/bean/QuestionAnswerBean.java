package com.maybank.carisma.questionnaire.bean;

import java.io.Serializable;

import com.maybank.carisma.questionnaire.vo.OptionTypes;

public class QuestionAnswerBean implements Serializable {

	private static final long serialVersionUID = 1225329864268402950L;
	
	QuestionAnswerKeyBean questionAnswerKey;

	private OptionTypes optionTypes;

	private String answerId;

	private String answerDesc;

	private long sectionOrder;
	
	private String remark;

	public QuestionAnswerKeyBean getQuestionAnswerKey() {
		return questionAnswerKey;
	}

	public QuestionAnswerBean setQuestionAnswerKey(QuestionAnswerKeyBean questionAnswerKey) {
		this.questionAnswerKey = questionAnswerKey;
		return this;
	}

	public OptionTypes getOptionTypes() {
		return optionTypes;
	}

	public QuestionAnswerBean setOptionTypes(OptionTypes optionTypes) {
		this.optionTypes = optionTypes;
		return this;
	}

	public String getAnswerId() {
		return answerId;
	}

	public QuestionAnswerBean setAnswerId(String answerId) {
		this.answerId = answerId;
		return this;
	}

	public String getAnswerDesc() {
		return answerDesc;
	}

	public QuestionAnswerBean setAnswerDesc(String answerDesc) {
		this.answerDesc = answerDesc;
		return this;
	}

	public long getSectionOrder() {
		return sectionOrder;
	}

	public QuestionAnswerBean setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
		return this;
	}

	public String getRemark() {
		return remark;
	}

	public QuestionAnswerBean setRemark(String remark) {
		this.remark = remark;
		return this;
	}

	@Override
	public String toString() {
		return "QuestionAnswerBean [questionAnswerKey=" + questionAnswerKey + ", optionTypes=" + optionTypes
				+ ", answerId=" + answerId + ", answerDesc=" + answerDesc + ", sectionOrder=" + sectionOrder
				+ ", remark=" + remark + "]";
	}
	
}
