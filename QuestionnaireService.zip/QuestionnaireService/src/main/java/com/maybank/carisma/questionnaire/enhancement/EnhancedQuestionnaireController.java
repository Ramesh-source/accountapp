package com.maybank.carisma.questionnaire.enhancement;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.maybank.carisma.constant.ExecutionStatus;
import com.maybank.carisma.questionnaire.constant.QuestionnaireConstant;
import com.maybank.carisma.questionnaire.enhancement.service.EnhancedQuestionnaireService;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerDTO;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerResponseDTO;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.QuestionSectionSaveVo;
import com.maybank.carisma.questionnaire.vo.SelectOption;

@Controller
@RequestMapping("/")
public class EnhancedQuestionnaireController {

	private static final Logger LOGGER = LogManager.getLogger(EnhancedQuestionnaireController.class);

	@Autowired
	EnhancedQuestionnaireService enhancedQuestionnaireService;

	@RequestMapping(value = { "/getQuestionnaire" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionResponse getQuestionnaire(@RequestBody QuestionSectionSaveVo request) {

		long startTime = System.currentTimeMillis();		
		QuestionResponse response = new QuestionResponse();

		try {
			enhancedQuestionnaireService.getQuestionnaire(request, response);
		} catch (Exception e) {
			LOGGER.error("Error on EnhancedQuestionnaireController :: getQuestionnaire: " + e.getMessage());
			e.printStackTrace();
			response.addErrorDetail(e.getMessage());
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return response;
		} catch (Throwable e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			response.addErrorDetail(e.getStackTrace().toString());
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
		} 
		finally {
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
		}

		return response;
	}

	@RequestMapping(value = { "/getQuestionnaireMetaData" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionResponse getQuestionnaireMetaData(@RequestBody QuestionSectionSaveVo request) {
		long startTime = System.currentTimeMillis();		
		QuestionResponse response = new QuestionResponse();

		try {
			enhancedQuestionnaireService.populateQuestionnaireMetaData(request, response);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			response.addErrorDetail(e.getStackTrace().toString());
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return response;
		} catch (Throwable e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			response.addErrorDetail(e.getMessage());
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
		}
		finally {
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
		}

		return response;
	}

	@RequestMapping(value = { "/saveOrUpdateQuestionAnswer" }, method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ResponseBody
	public QuestionResponse saveOrUpdateQuestionAnswer(@RequestBody QuestionSectionSaveVo request) {
		if(request == null)
			return null;
		
		long startTime = System.currentTimeMillis();

		QuestionResponse questionResponse = new QuestionResponse();
		Boolean isMandatoryCheckFailed = request.getIsMandatoryCheckFailed();

		try {
			QuestionAnswerResponseDTO questionAnswerResponseDTO = enhancedQuestionnaireService.saveOrUpdateQuestionAnswer(request);
			questionResponse.setQuestionAnswerResponseDTO(questionAnswerResponseDTO);		
			questionResponse.setExecutionStatus(QuestionnaireConstant.MSG_CODE_01);
			
			if(isMandatoryCheckFailed != null && isMandatoryCheckFailed.equals(Boolean.TRUE)) {
				questionResponse.setServiceStatus(QuestionnaireConstant.QUESTIONNAIRE_SAVED_AS_DRAFT);
			} else {
				questionResponse.setServiceStatus(QuestionnaireConstant.QUESTIONNAIRE_SAVED);
			}			

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			questionResponse.addErrorDetail(e.getMessage());
			questionResponse.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return questionResponse;
		} catch (Throwable e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			questionResponse.addErrorDetail(e.getMessage());
			questionResponse.setExecutionStatus(ExecutionStatus.ERROR.toString());
		} 
		finally {
			long endTime = System.currentTimeMillis();
			questionResponse.setResponseTime(endTime - startTime);
		}

		return questionResponse;
	}

	@RequestMapping(value = { "/getAllQuestionnaire" }, method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public QuestionResponse getAllQuestionnaire() {
		long startTime = System.currentTimeMillis();
		QuestionResponse response = new QuestionResponse();

		try {
			List<SelectOption> selectOptionList = enhancedQuestionnaireService.getAllQuestionnaire();
			response.setSelectOptions(selectOptionList);
			response.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			response.addErrorDetail("Error occured while saving questions and answers");
			response.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return response;
		}
		finally {
			long endTime = System.currentTimeMillis();
			response.setResponseTime(endTime - startTime);
		}
	}

	@RequestMapping(value = "/getQuestionAnswerByRequestId", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody 
	public QuestionAnswerResponseDTO getQuestionAnswerByRequestId(@RequestParam("requestId") Long requestId) {
		long startTime = System.currentTimeMillis();
		QuestionAnswerResponseDTO questionAnswerResponseDTO = new QuestionAnswerResponseDTO();

		try {
			List<QuestionAnswerDTO> questionAnswerDTOList = enhancedQuestionnaireService.getQuestionAnswerByRequestId(requestId);
			questionAnswerResponseDTO.setQuestionAnswerDTOList(questionAnswerDTOList);
			questionAnswerResponseDTO.setExecutionStatus(ExecutionStatus.COMPLETED.toString());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			questionAnswerResponseDTO.addErrorDetail("Error occured while saving questions and answers");
			questionAnswerResponseDTO.setExecutionStatus(ExecutionStatus.ERROR.toString());
			return questionAnswerResponseDTO;
		}
		finally {
			long endTime = System.currentTimeMillis();
			questionAnswerResponseDTO.setResponseTime(endTime - startTime);
		}

		return questionAnswerResponseDTO;
	}

}
