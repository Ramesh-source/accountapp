package com.maybank.carisma.questionnaire.vo;

import java.util.List;

public class QuestionSaveInfo {

	private long sectionId;
	
	private List<QuestionSectionSaveVo> sectionSaveVo;

	public long getSectionId() {
		return sectionId;
	}

	public void setSectionId(long sectionId) {
		this.sectionId = sectionId;
	}

	public List<QuestionSectionSaveVo> getSectionSaveVo() {
		return sectionSaveVo;
	}

	public void setSectionSaveVo(List<QuestionSectionSaveVo> sectionSaveVo) {
		this.sectionSaveVo = sectionSaveVo;
	}

}
