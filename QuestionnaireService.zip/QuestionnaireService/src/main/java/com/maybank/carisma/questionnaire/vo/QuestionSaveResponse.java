package com.maybank.carisma.questionnaire.vo;

import com.maybank.carisma.vo.common.BaseResponseObject;

/**
 * The Class QuestionSaveResponse.
 * 
 *  @author Sangit Banik
 */
public class QuestionSaveResponse extends BaseResponseObject{

}
