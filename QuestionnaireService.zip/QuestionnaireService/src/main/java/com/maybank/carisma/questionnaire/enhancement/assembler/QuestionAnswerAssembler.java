package com.maybank.carisma.questionnaire.enhancement.assembler;

import java.util.List;

import org.springframework.stereotype.Component;

import com.maybank.carisma.questionnaire.entity.QuestionAnswer;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerDTO;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerResponseDTO;

@Component("questionAnswerAssembler")
public class QuestionAnswerAssembler {

	public void fromEntity(QuestionAnswer questionAnswer, QuestionAnswerDTO questionAnswerDTO) {

		if (questionAnswer != null && questionAnswer.getQuestionAnswerKey() != null) {
			if (questionAnswerDTO == null) {
				questionAnswerDTO = new QuestionAnswerDTO();
			}
			questionAnswerDTO.setRequestId(questionAnswer.getQuestionAnswerKey().getRequestId());
			questionAnswerDTO.setQuestionnaireId(questionAnswer.getQuestionAnswerKey().getQuestionnaireId());
			questionAnswerDTO.setQuestionId(questionAnswer.getQuestionAnswerKey().getQuestionId());
			questionAnswerDTO.setModuleName(questionAnswer.getQuestionAnswerKey().getModuleName());
			questionAnswerDTO.setOptionTypes(questionAnswer.getOptionTypes());
			questionAnswerDTO.setAnswerId(questionAnswer.getAnswerId());
			questionAnswerDTO.setAnswerDesc(questionAnswer.getAnswerDesc());
			questionAnswerDTO.setSectionOrder(questionAnswer.getSectionOrder());
			
			questionAnswerDTO.setCommentDesc(questionAnswer.getRemark());
		}

	}

	public QuestionAnswerResponseDTO constructQuestionAnswerResponseDTO(List<QuestionAnswerDTO> qaList, QuestionAnswer questionAnswer) {
		QuestionAnswerResponseDTO questionAnswerResponseDTO = new QuestionAnswerResponseDTO();
		questionAnswerResponseDTO.setQuestionAnswerDTOList(qaList);
		questionAnswerResponseDTO.setRequestId(questionAnswer.getQuestionAnswerKey().getRequestId());
		questionAnswerResponseDTO.setQuestionnaireId(questionAnswer.getQuestionAnswerKey().getQuestionnaireId());
		questionAnswerResponseDTO.setModuleName(questionAnswer.getQuestionAnswerKey().getModuleName());
		return questionAnswerResponseDTO;
	}
}
