package com.maybank.carisma.questionnaire.entity;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "QUESTIONNAIRE_SECTIONS")
@NamedQueries({
		@NamedQuery(name="QuestionnaireSections.findAll", query="SELECT q FROM QuestionnaireSections q"),
		@NamedQuery(name = QuestionnaireSections.GET_QUESTIONNAIRE_SECTIONS_BY_ORDER, query = "SELECT qs FROM QuestionnaireSections qs WHERE qs.questionnaire.nQuestionnaireId = :questionnaireId AND qs.sectionOrder = :sectionOrder"),
		@NamedQuery(name = QuestionnaireSections.GET_QUESTIONNAIRE_SECTIONS_BY_QUESTIONNAIRE_ID, query = "SELECT qs FROM QuestionnaireSections qs WHERE qs.questionnaire.nQuestionnaireId = :questionnaireId order by qs.sectionOrder") })
public class QuestionnaireSections implements Serializable {

	private static final long serialVersionUID = -4952925266269874746L;

	public static final String GET_QUESTIONNAIRE_SECTIONS_BY_ORDER = "GET_QUESTIONNAIRE_SECTIONS_BY_ORDER";

	public static final String GET_QUESTIONNAIRE_SECTIONS_BY_QUESTIONNAIRE_ID = "GET_QUESTIONNAIRE_SECTIONS_BY_QUESTIONNAIRE_ID";

	@Id
	@SequenceGenerator(name = "questionnaireSections", sequenceName = "SEQ_QUESTIONNAIRE_SECTIONS_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "questionnaireSections")
	@Column(name = "N_QUESTIONNAIRE_SECTIONS_ID")
	private long nQuestionnaireSectionsId;

	@ManyToOne
	@JoinColumn(name = "N_QUESTIONNAIRE_ID")
	private Questionnaire questionnaire;

	@Column(name = "V_SECTION_CODE")
	private String sectionCode;

	@Column(name = "N_SECTION_ORDER")
	private long sectionOrder;

	@Column(name = "F_MULTIPLE_RESPONSES")
	private String fMulpitpleSections;

	@Column(name = "V_RESPONSE_STYLE")
	private String responseStyle;

	@Column(name = "V_RESPONSE_TABLE")
	private String responseTable;

	@Column(name = "V_SECTION_HREF")
	private String sectionHref;

	@OneToMany(mappedBy = "questionnaireSections")
	private Set<QuestionnaireQuestionMap> questionnaireQuestionMaps;

	public long getnQuestionnaireSectionsId() {
		return nQuestionnaireSectionsId;
	}

	public void setnQuestionnaireSectionsId(long nQuestionnaireSectionsId) {
		this.nQuestionnaireSectionsId = nQuestionnaireSectionsId;
	}

	public Questionnaire getQuestionnaire() {
		return questionnaire;
	}

	public void setQuestionnaire(Questionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

	public String getSectionCode() {
		return sectionCode;
	}

	public void setSectionCode(String sectionCode) {
		this.sectionCode = sectionCode;
	}

	public long getSectionOrder() {
		return sectionOrder;
	}

	public void setSectionOrder(long sectionOrder) {
		this.sectionOrder = sectionOrder;
	}

	public String getfMulpitpleSections() {
		return fMulpitpleSections;
	}

	public void setfMulpitpleSections(String fMulpitpleSections) {
		this.fMulpitpleSections = fMulpitpleSections;
	}
	
	public String getSectionHref() {
		return sectionHref;
	}

	public void setSectionHref(String sectionHref) {
		this.sectionHref = sectionHref;
	}	

}
