/**
 * 
 */
package com.maybank.carisma.questionnaire.enhancement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.maybank.carisma.questionnaire.enhancement.enumeration.dao.EnhancedQuestionnaireServiceDAO;
import com.maybank.carisma.questionnaire.enhancement.service.EnhancedQuestionnaireServiceHelper;
import com.maybank.carisma.questionnaire.entity.QuestionMaster;
import com.maybank.carisma.questionnaire.service.QuestionnaireService;
import com.maybank.carisma.questionnaire.vo.QuestionMasterValidationBean;

/**
 * @author 00132020
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ServiceTests {
	
	/** The mock mvc. */
	private MockMvc mockMvc;
	
	@Mock
	QuestionnaireService questionnaireService;
	
	@Mock
	EnhancedQuestionnaireServiceDAO enhancedQuestionnaireServiceDAO;

	@InjectMocks
	EnhancedQuestionnaireServiceHelper enhancedQuestionnaireServiceHelper;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders
                .standaloneSetup(enhancedQuestionnaireServiceHelper)
                .build();
	}
	
	@Test
	public void convertQuestionTypeTest() {
		QuestionMaster qm = new QuestionMaster();
		qm.setNQuestionMasterId((long) 1);
		qm.setVOptionSelectionType("H");
		qm.setVQuestion("QST_DEMO1_01");
		qm.setQuestionTooltip("MANDATORY_VALIDATION");
		qm.setQuestionHref("HREF_LINK");
		List<QuestionMaster> qmList = new ArrayList<QuestionMaster>();
		qmList.add(qm);
		Locale loc = new Locale("en_US");

		Map<String, Map<Locale, String>> infoMap = new HashMap<String, Map<Locale, String>>();
		Map<Locale, String> localeMap1 = new HashMap<Locale, String>();
		localeMap1.put(loc, "Are you a Malaysian?");
		infoMap.put("QST_DEMO1_01", localeMap1);
		Map<Locale, String> localeMap2 = new HashMap<Locale, String>();
		localeMap2.put(loc, "Please enter whether your are a resident of Malaysia!");
		infoMap.put("MANDATORY_VALIDATION", localeMap2);
		Map<Locale, String> localeMap3 = new HashMap<Locale, String>();
		localeMap3.put(loc, "Only digits allowed!");
		infoMap.put("NUMBER_VALIDATION_QST_DEMO1_08", localeMap3);
		QuestionnaireService.infoMap = infoMap;
		
		Map<Long, List<QuestionMasterValidationBean>> validationVoListMap = new HashMap<Long, List<QuestionMasterValidationBean>>();
		QuestionMasterValidationBean validationVo = new QuestionMasterValidationBean();
		validationVo.setValidationType("REGEX");
		validationVo.setName("REGEX");
		
		validationVo.setValidationValue("STRING");
		validationVo.setValue("STRING");
		
		validationVo.setErrorCode("NUMBER_VALIDATION_QST_DEMO1_08");
		List<QuestionMasterValidationBean> validationVoList = new ArrayList<QuestionMasterValidationBean>();
		validationVoList.add(validationVo);
		validationVoListMap.put((long) 1, validationVoList);
		QuestionnaireService.mapValidationsByQuestionnaireId = validationVoListMap;
		
		Mockito.when(enhancedQuestionnaireServiceDAO.getRegexValue("STRING")).thenReturn("^[a-zA-Z ]*$");
		
		enhancedQuestionnaireServiceHelper.constructQuestionMaster(qmList, loc);
	}
}
