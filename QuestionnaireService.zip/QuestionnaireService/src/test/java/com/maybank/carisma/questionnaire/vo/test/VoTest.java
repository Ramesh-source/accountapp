package com.maybank.carisma.questionnaire.vo.test;

import org.junit.Test;

import com.maybank.carisma.questionnaire.vo.ExtendedValues;
import com.maybank.carisma.questionnaire.vo.OptionDTO;
import com.maybank.carisma.questionnaire.vo.OptionTypes;
import com.maybank.carisma.questionnaire.vo.QuestionAnswerVo;
import com.maybank.carisma.questionnaire.vo.QuestionDTO;
import com.maybank.carisma.questionnaire.vo.QuestionDescVo;
import com.maybank.carisma.questionnaire.vo.QuestionRequest;
import com.maybank.carisma.questionnaire.vo.QuestionResponse;
import com.maybank.carisma.questionnaire.vo.QuestionSaveInfo;
import com.maybank.carisma.questionnaire.vo.QuestionSaveResponse;
import com.maybank.carisma.questionnaire.vo.QuestionSectionSaveVo;
import com.maybank.carisma.questionnaire.vo.QuestionnaireDTO;
import com.maybank.carisma.questionnaire.vo.QuestionnaireProperties;
import com.maybank.carisma.questionnaire.vo.QuestionnaireSaveRequest;
import com.maybank.carisma.questionnaire.vo.SectionDetails;
import com.maybank.carisma.questionnaire.vo.SectionProperties;
import com.maybank.carisma.questionnaire.vo.SortBySortOrder;
import com.maybank.carisma.questionnaire.vo.SubSectionDetails;
import com.maybank.carisma.questionnaire.vo.TypeOfDisplay;
import com.maybank.carisma.questionnaire.vo.QuestionMasterValidationBean;


public class VoTest {

	@Test
	public void testAccesors_shouldAccessProperField() {


		PojoTestUtils.validateAccessors(ExtendedValues.class);
		PojoTestUtils.validateAccessors(OptionDTO.class);
		PojoTestUtils.validateAccessors(OptionTypes.class);
		
		PojoTestUtils.validateAccessors(QuestionAnswerVo.class);
		PojoTestUtils.validateAccessors(QuestionDescVo.class);
		PojoTestUtils.validateAccessors(QuestionDTO.class);
		PojoTestUtils.validateAccessors(QuestionnaireDTO.class);
		PojoTestUtils.validateAccessors(QuestionnaireProperties.class);
		PojoTestUtils.validateAccessors(QuestionnaireSaveRequest.class);
		PojoTestUtils.validateAccessors(QuestionRequest.class);
		PojoTestUtils.validateAccessors(QuestionResponse.class);
		PojoTestUtils.validateAccessors(QuestionSaveInfo.class);
		PojoTestUtils.validateAccessors(QuestionSaveResponse.class);
		PojoTestUtils.validateAccessors(QuestionSectionSaveVo.class);
		PojoTestUtils.validateAccessors(SectionDetails.class);
		PojoTestUtils.validateAccessors(SectionProperties.class);
		PojoTestUtils.validateAccessors(SortBySortOrder.class);
		PojoTestUtils.validateAccessors(TypeOfDisplay.class);
		PojoTestUtils.validateAccessors(SubSectionDetails.class);
		//PojoTestUtils.validateAccessors(QuestionMasterValidationBean.class);
	

	
	}
}
