package com.maybank.carisma.questionnaire.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.maybank.carisma.dao.commonQuestionnaire.QuestionnaireSaveDao;
import com.maybank.carisma.questionnaire.test.config.JpaTestConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes={JpaTestConfig.class}, loader =AnnotationConfigContextLoader.class)
@SqlGroup({
@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = {
"classpath:Questionnaire_save.sql",
"classpath:Questionnaire_service.sql"}),
@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = {
"classpath:questionnaire_save_delete.sql",
"classpath:questionnaire_delete.sql"
}) })
public class QuestionnaireSaveTest {
	
	@Autowired
	QuestionnaireSaveDao dao;
	
	@Test
	public void columnInsertTest() {
		List<String> columnNames = new ArrayList<String>();
		List<Object> columnValues= new ArrayList<Object>();
		String tableName = "FATCA_IND";
		dao.insertColumnQuestionnaire(columnNames, columnValues, tableName, "UIND", "FATCA", "NUR");
	
	}
}
