package com.maybank.carisma.questionnaire.vo.test;

import org.junit.Test;

import com.maybank.carisma.questionnaire.entity.AvlOptionsToQuestion;
import com.maybank.carisma.questionnaire.entity.QuestionMaster;
import com.maybank.carisma.questionnaire.entity.QuestionMasterValidation;
import com.maybank.carisma.questionnaire.entity.QuestionOptionsNavigation;
import com.maybank.carisma.questionnaire.entity.Questionnaire;
import com.maybank.carisma.questionnaire.entity.QuestionnaireQuestionMap;
import com.maybank.carisma.questionnaire.entity.QuestionnaireSections;

public class EntityTest {

	@Test
	public void testAccesors_shouldAccessProperField() {

		PojoTestUtils.validateAccessors(AvlOptionsToQuestion.class);
		PojoTestUtils.validateAccessors(QuestionMaster.class);
		PojoTestUtils.validateAccessors(QuestionMasterValidation.class);
		PojoTestUtils.validateAccessors(QuestionMasterValidation.class);
		PojoTestUtils.validateAccessors(QuestionOptionsNavigation.class);
		PojoTestUtils.validateAccessors(QuestionnaireSections.class);
		PojoTestUtils.validateAccessors(Questionnaire.class);
		PojoTestUtils.validateAccessors(QuestionnaireQuestionMap.class);
	}
	
}
